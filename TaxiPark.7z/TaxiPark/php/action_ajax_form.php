<?php

if (isset($_POST["surname"]) && isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["phonenumber"]) && isset($_POST["datebooking"])) { 

	// Формируем массив для JSON ответа
    $result = array(
    	'surname' => $_POST["surname"],
    	'name' => $_POST["name"],
    	'email' => $_POST["email"],
    	'phonenumber' => $_POST["phonenumber"],
    	'datebooking' => $_POST["datebooking"]
    ); 

    // Переводим массив в JSON
    echo json_encode($result); 
}

?>
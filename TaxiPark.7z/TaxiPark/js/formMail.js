$("#sendMail").on("click", function) {
	var email = $("#email").val();
	var email = $("#phone").val();
	var email = $("#password").val();

	if(email == "") {
		$("#errorMess").text("Write email");
		return false;
	} else if(phone == "") {
		$("#errorMess").text("Write email");
		return false;
	}

	$("#errorMess").text("");

	
});